import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  Download, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  ExternalLink,
  FileArchive,
  CheckSquare,
  Square,
  Eye,
  X,
  RefreshCw,
  Settings2,
  Clock,
  Play,
  Pause,
  Trash2,
  ListOrdered,
  Plus,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Maximize,
  RotateCcw,
  Info,
  User,
  Calendar,
  Tag,
  Fingerprint
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import JSZip from "jszip";
import axios from "axios";
import * as pdfjs from "pdfjs-dist";

// Set up PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

interface PDFMetadata {
  title?: string;
  author?: string;
  creator?: string;
  producer?: string;
  creationDate?: string;
  modificationDate?: string;
  pages?: number;
}

interface PDFLink {
  url: string;
  name: string;
  metadata?: PDFMetadata;
  isExtractingMetadata?: boolean;
}

type DownloadStatus = 'queued' | 'downloading' | 'completed' | 'failed' | 'paused' | 'cancelled';

interface QueueTask {
  id: string;
  name: string;
  url: string;
  status: DownloadStatus;
  progress: number;
  speed?: string;
  error?: string;
  abortController?: AbortController;
}

interface BulkDownloadStatus {
  currentFile: string;
  percent: number;
  completed: number;
  total: number;
}

export default function App() {
  const [url, setUrl] = useState("");
  const [pdfs, setPdfs] = useState<PDFLink[]>([]);
  const [selectedUrls, setSelectedUrls] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [error, setError] = useState<{ message: string; detail?: string; code?: string } | null>(null);
  const [previewPdf, setPreviewPdf] = useState<PDFLink | null>(null);
  const [bulkStatus, setBulkStatus] = useState<BulkDownloadStatus | null>(null);
  const [requestDelay, setRequestDelay] = useState(1000); // Default 1s delay
  const [showSettings, setShowSettings] = useState(false);
  
  // Preview State
  const [previewPage, setPreviewPage] = useState(1);
  const [previewZoom, setPreviewZoom] = useState(100);
  const [previewFit, setPreviewFit] = useState(false);
  const [isExtractingGlobal, setIsExtractingGlobal] = useState(false);

  // Queue State
  const [queue, setQueue] = useState<QueueTask[]>([]);
  const [maxConcurrent, setMaxConcurrent] = useState(2);
  const queueRef = useRef<QueueTask[]>([]);

  // Sync ref with state for use in async loops
  useEffect(() => {
    queueRef.current = queue;
  }, [queue]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setIsLoading(true);
    setError(null);
    setPdfs([]);
    setSelectedUrls(new Set());

    try {
      const response = await fetch("/api/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          url: url.trim(),
          delay: requestDelay 
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setError({ 
          message: data.error || "Failed to scrape website", 
          detail: data.detail,
          code: data.code
        });
        return;
      }

      setPdfs(data.pdfs);
      if (data.pdfs.length === 0) {
        setError({ message: "No PDF files found on this page. Some websites load content dynamically with JavaScript, which our crawler might not see." });
      }
    } catch (err: any) {
      setError({ message: err.message });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSelect = (pdfUrl: string) => {
    const newSelected = new Set(selectedUrls);
    if (newSelected.has(pdfUrl)) {
      newSelected.delete(pdfUrl);
    } else {
      newSelected.add(pdfUrl);
    }
    setSelectedUrls(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedUrls.size === pdfs.length) {
      setSelectedUrls(new Set());
    } else {
      setSelectedUrls(new Set(pdfs.map(p => p.url)));
    }
  };

  const addToQueue = (pdf: PDFLink) => {
    // Prevent duplicates
    if (queue.some(t => t.id === pdf.url)) {
      // Highlight existing task (optional, but let's just return for now)
      return;
    }
    
    const newTask: QueueTask = {
      id: pdf.url,
      name: pdf.name,
      url: pdf.url,
      status: 'queued',
      progress: 0
    };
    
    setQueue(prev => [...prev, newTask]);
  };

  const addSelectedToQueue = () => {
    const selectedPdfs = pdfs.filter(p => selectedUrls.has(p.url));
    const newTasks = selectedPdfs
      .filter(p => !queue.some(t => t.id === p.url))
      .map(p => ({
        id: p.url,
        name: p.name,
        url: p.url,
        status: 'queued' as const,
        progress: 0
      }));
    
    setQueue(prev => [...prev, ...newTasks]);
    setSelectedUrls(new Set());
  };

  const removeFromQueue = (id: string) => {
    const task = queue.find(t => t.id === id);
    if (task?.abortController) {
      task.abortController.abort();
    }
    setQueue(prev => prev.filter(t => t.id !== id));
  };

  const toggleTaskStatus = (id: string) => {
    setQueue(prev => prev.map(t => {
      if (t.id === id) {
        if (t.status === 'downloading') {
          t.abortController?.abort();
          return { ...t, status: 'paused' as const, abortController: undefined };
        } else if (t.status === 'paused' || t.status === 'failed' || t.status === 'cancelled') {
          return { ...t, status: 'queued' as const, progress: 0, error: undefined };
        }
      }
      return t;
    }));
  };

  const downloadInPackets = async (task: QueueTask, controller: AbortController) => {
    let startTime = Date.now();
    let lastLoaded = 0;

    const updateSpeed = (loaded: number) => {
      const now = Date.now();
      const duration = (now - startTime) / 1000;
      if (duration > 0.5) { // Update every 0.5s
        const bytesPerSec = loaded / duration;
        let speedStr = "";
        if (bytesPerSec > 1024 * 1024) {
          speedStr = `${(bytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`;
        } else {
          speedStr = `${(bytesPerSec / 1024).toFixed(1)} KB/s`;
        }
        setQueue(prev => prev.map(t => t.id === task.id ? { ...t, speed: speedStr } : t));
      }
    };

    try {
      // 1. Get Info
      const infoRes = await axios.get(`/api/pdf-info?url=${encodeURIComponent(task.url)}`, { signal: controller.signal });
      const { size, acceptRanges } = infoRes.data;

      // 2. Decide if we use packets (only if > 1MB and ranges supported)
      const usePackets = acceptRanges && size > 1024 * 1024;
      const packetCount = 4;

      if (!usePackets) {
        // Standard download
        const response = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(task.url)}&delay=${requestDelay}`, {
          responseType: "blob",
          signal: controller.signal,
          onDownloadProgress: (progressEvent) => {
            if (progressEvent.total) {
              const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
              updateSpeed(progressEvent.loaded);
              setQueue(prev => prev.map(t => t.id === task.id ? { ...t, progress: percent } : t));
            }
          }
        });
        return response.data;
      }

      // 3. Chunked Download
      const chunkSize = Math.ceil(size / packetCount);
      const chunks: Blob[] = [];
      let loadedBytes = 0;

      const downloadChunk = async (index: number) => {
        const start = index * chunkSize;
        const end = Math.min(start + chunkSize - 1, size - 1);
        
        const res = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(task.url)}&range=bytes=${start}-${end}`, {
          responseType: "blob",
          signal: controller.signal,
          onDownloadProgress: (progressEvent) => {
            // Approximate speed for chunked is harder, but we can track total loaded
          }
        });
        
        chunks[index] = res.data;
        loadedBytes += res.data.size;
        updateSpeed(loadedBytes);
        const totalPercent = Math.round((loadedBytes * 100) / size);
        setQueue(prev => prev.map(t => t.id === task.id ? { ...t, progress: totalPercent } : t));
      };

      // Download all chunks in parallel
      await Promise.all(Array.from({ length: packetCount }).map((_, i) => downloadChunk(i)));

      return new Blob(chunks, { type: "application/pdf" });
    } catch (err) {
      throw err;
    }
  };

  const processQueue = useCallback(async () => {
    const activeTasks = queueRef.current.filter(t => t.status === 'downloading').length;
    if (activeTasks >= maxConcurrent) return;

    const nextTask = queueRef.current.find(t => t.status === 'queued');
    if (!nextTask) return;

    const controller = new AbortController();
    
    setQueue(prev => prev.map(t => 
      t.id === nextTask.id ? { ...t, status: 'downloading' as const, abortController: controller } : t
    ));

    try {
      const blob = await downloadInPackets(nextTask, controller);

      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = nextTask.name.endsWith(".pdf") ? nextTask.name : `${nextTask.name}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setQueue(prev => prev.map(t => 
        t.id === nextTask.id ? { ...t, status: 'completed' as const, progress: 100, abortController: undefined } : t
      ));
    } catch (err: any) {
      if (axios.isCancel(err)) {
        // Handled
      } else {
        console.error("Queue task failed:", err);
        setQueue(prev => prev.map(t => 
          t.id === nextTask.id ? { ...t, status: 'failed' as const, error: err.message, abortController: undefined } : t
        ));
      }
    }
  }, [maxConcurrent, requestDelay]);

  useEffect(() => {
    const timer = setInterval(() => {
      processQueue();
    }, 500);
    return () => clearInterval(timer);
  }, [processQueue]);

  const downloadAsZip = async () => {
    if (selectedUrls.size === 0) return;

    setIsDownloadingZip(true);
    const selectedPdfs = pdfs.filter(p => selectedUrls.has(p.url));
    setBulkStatus({
      currentFile: "",
      percent: 0,
      completed: 0,
      total: selectedPdfs.length
    });

    const zip = new JSZip();

    try {
      for (let i = 0; i < selectedPdfs.length; i++) {
        const pdf = selectedPdfs[i];
        setBulkStatus(prev => prev ? { ...prev, currentFile: pdf.name, percent: 0 } : null);

        const response = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(pdf.url)}&delay=${requestDelay}`, {
          responseType: "blob",
          onDownloadProgress: (progressEvent) => {
            if (progressEvent.total) {
              const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
              setBulkStatus(prev => prev ? { ...prev, percent: percentCompleted } : null);
            }
          }
        });

        zip.file(pdf.name.endsWith(".pdf") ? pdf.name : `${pdf.name}.pdf`, response.data);
        setBulkStatus(prev => prev ? { ...prev, completed: i + 1, percent: 100 } : null);
      }

      setBulkStatus(prev => prev ? { ...prev, currentFile: "Generating ZIP archive..." } : null);
      const content = await zip.generateAsync({ type: "blob" });
      const downloadUrl = window.URL.createObjectURL(content);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = `pdfs_bulk_${new Date().getTime()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err: any) {
      setError({ message: "Error during bulk download: " + err.message });
    } finally {
      setIsDownloadingZip(false);
      setBulkStatus(null);
    }
  };

  const downloadSingle = async (pdf: PDFLink) => {
    try {
      const response = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(pdf.url)}`, {
        responseType: "blob"
      });
      const downloadUrl = window.URL.createObjectURL(response.data);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = pdf.name.endsWith(".pdf") ? pdf.name : `${pdf.name}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err: any) {
      setError({ message: "Failed to download file: " + err.message });
    }
  };

  const extractMetadata = async (pdf: PDFLink) => {
    if (pdf.metadata || pdf.isExtractingMetadata) return;

    setPdfs(prev => prev.map(p => p.url === pdf.url ? { ...p, isExtractingMetadata: true } : p));

    try {
      const response = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(pdf.url)}`, {
        responseType: "arraybuffer",
        headers: {
          "Range": "bytes=0-65536" // Try to get just the beginning for metadata
        }
      });

      const loadingTask = pdfjs.getDocument({ data: response.data });
      const pdfDoc = await loadingTask.promise;
      const metadata = await pdfDoc.getMetadata();
      
      const info = metadata.info as any;
      const pdfMetadata: PDFMetadata = {
        title: info?.Title || "",
        author: info?.Author || "",
        creator: info?.Creator || "",
        producer: info?.Producer || "",
        creationDate: info?.CreationDate || "",
        modificationDate: info?.ModDate || "",
        pages: pdfDoc.numPages
      };

      setPdfs(prev => prev.map(p => p.url === pdf.url ? { ...p, metadata: pdfMetadata, isExtractingMetadata: false } : p));
      
      // If this is the current preview, update it too
      if (previewPdf?.url === pdf.url) {
        setPreviewPdf(prev => prev ? { ...prev, metadata: pdfMetadata } : null);
      }
    } catch (err) {
      console.error("Metadata extraction failed:", err);
      // Fallback: try full download if range fails or metadata is elsewhere
      try {
        const response = await axios.get(`/api/proxy-pdf?url=${encodeURIComponent(pdf.url)}`, {
          responseType: "arraybuffer"
        });
        const loadingTask = pdfjs.getDocument({ data: response.data });
        const pdfDoc = await loadingTask.promise;
        const metadata = await pdfDoc.getMetadata();
        const info = metadata.info as any;
        const pdfMetadata: PDFMetadata = {
          title: info?.Title || "",
          author: info?.Author || "",
          creator: info?.Creator || "",
          producer: info?.Producer || "",
          creationDate: info?.CreationDate || "",
          modificationDate: info?.ModDate || "",
          pages: pdfDoc.numPages
        };
        setPdfs(prev => prev.map(p => p.url === pdf.url ? { ...p, metadata: pdfMetadata, isExtractingMetadata: false } : p));
        if (previewPdf?.url === pdf.url) {
          setPreviewPdf(prev => prev ? { ...prev, metadata: pdfMetadata } : null);
        }
      } catch (innerErr) {
        setPdfs(prev => prev.map(p => p.url === pdf.url ? { ...p, isExtractingMetadata: false } : p));
      }
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return "Unknown";
    // PDF dates are often in format D:YYYYMMDDHHmmSSOHH'mm'
    if (dateStr.startsWith("D:")) {
      const year = dateStr.substring(2, 6);
      const month = dateStr.substring(6, 8);
      const day = dateStr.substring(8, 10);
      return `${year}-${month}-${day}`;
    }
    return dateStr;
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-blue-100 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-[#E5E7EB] px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <FileText className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">PDF Collector</h1>
              <p className="text-xs text-[#6B7280] font-medium uppercase tracking-wider">Bulk Downloader</p>
            </div>
          </div>
          
          {pdfs.length > 0 && (
            <div className="flex items-center gap-4">
              <button
                onClick={toggleSelectAll}
                className="text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors flex items-center gap-2"
              >
                {selectedUrls.size === pdfs.length ? (
                  <><CheckSquare className="w-4 h-4" /> Deselect All</>
                ) : (
                  <><Square className="w-4 h-4" /> Select All</>
                )}
              </button>
              <button
                onClick={() => {
                  const allUrls = new Set(pdfs.map(p => p.url));
                  setSelectedUrls(allUrls);
                  // Use a timeout to ensure state updates before calling addSelectedToQueue
                  // Or better, just implement a direct QueueAll logic
                  const newTasks = pdfs
                    .filter(p => !queue.some(t => t.id === p.url))
                    .map(p => ({
                      id: p.url,
                      name: p.name,
                      url: p.url,
                      status: 'queued' as const,
                      progress: 0
                    }));
                  setQueue(prev => [...prev, ...newTasks]);
                  setSelectedUrls(new Set());
                }}
                className="text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors flex items-center gap-2"
              >
                <ListOrdered className="w-4 h-4" /> Queue All ({pdfs.length})
              </button>
              <button
                onClick={addSelectedToQueue}
                disabled={selectedUrls.size === 0}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-sm",
                  selectedUrls.size > 0 
                    ? "bg-blue-50 text-blue-600 hover:bg-blue-100" 
                    : "bg-gray-50 text-gray-300 cursor-not-allowed"
                )}
              >
                <Plus className="w-4 h-4" /> Add to Queue ({selectedUrls.size})
              </button>
              <button
                onClick={downloadAsZip}
                disabled={selectedUrls.size === 0 || isDownloadingZip}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-sm",
                  selectedUrls.size > 0 
                    ? "bg-blue-600 text-white hover:bg-blue-700 active:scale-95" 
                    : "bg-gray-100 text-gray-400 cursor-not-allowed"
                )}
              >
                {isDownloadingZip ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Processing...</>
                ) : (
                  <><FileArchive className="w-4 h-4" /> Download ZIP ({selectedUrls.size})</>
                )}
              </button>
            </div>
          )}
        </div>
        
        {/* Settings Panel */}
        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="max-w-5xl mx-auto overflow-hidden"
            >
              <div className="pt-4 pb-2 flex flex-wrap items-center gap-x-12 gap-y-4 border-t border-gray-100 mt-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
                    <Clock className="w-4 h-4 text-blue-600" />
                    Request Delay:
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min="0"
                      max="5000"
                      step="500"
                      value={requestDelay}
                      onChange={(e) => setRequestDelay(parseInt(e.target.value))}
                      className="w-32 accent-blue-600"
                    />
                    <span className="text-xs font-mono font-bold bg-gray-100 px-2 py-1 rounded w-16 text-center">
                      {requestDelay}ms
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
                    <ListOrdered className="w-4 h-4 text-blue-600" />
                    Concurrent Downloads:
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min="1"
                      max="5"
                      step="1"
                      value={maxConcurrent}
                      onChange={(e) => setMaxConcurrent(parseInt(e.target.value))}
                      className="w-24 accent-blue-600"
                    />
                    <span className="text-xs font-mono font-bold bg-gray-100 px-2 py-1 rounded w-8 text-center">
                      {maxConcurrent}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-gray-400 italic w-full">
                  Higher delays and lower concurrency help bypass bot detection by mimicking human browsing speed.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        {/* Disclaimer */}
        <div className="mb-8 p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-4 shadow-sm">
          <div className="p-2 bg-amber-100 rounded-xl text-amber-600">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-amber-900 uppercase tracking-wider mb-1">Educational Purpose Only</h4>
            <p className="text-xs text-amber-800 leading-relaxed">
              This application is designed strictly for educational and research purposes. The developers are not responsible for any misuse or illegal activities performed with this tool. Users are solely responsible for ensuring they have the legal right to access and download content from target websites.
            </p>
          </div>
        </div>

        {/* Search Section */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-extrabold mb-3">Find PDFs from any URL</h2>
            <p className="text-[#6B7280] max-w-lg mx-auto">
              Enter a website URL below. We'll crawl the page and find all available PDF documents for you to download in bulk.
            </p>
          </div>

          <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto">
            <div className="relative group">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-gray-400 group-focus-within:text-blue-500 transition-colors">
                <Search className="w-5 h-5" />
              </div>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/documents"
                className="w-full pl-12 pr-32 py-4 bg-white border-2 border-[#E5E7EB] rounded-2xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-lg shadow-sm"
              />
              <button
                type="submit"
                disabled={isLoading || !url}
                className="absolute right-2 top-2 bottom-2 px-6 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed transition-all flex items-center gap-2"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Search"}
              </button>
            </div>
          </form>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-6 bg-red-50 border border-red-100 rounded-2xl flex flex-col gap-4 text-red-600 max-w-2xl mx-auto shadow-sm"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-lg">{error.message}</h3>
                </div>
                {error.code && (
                  <span className="text-[10px] font-mono bg-red-100 px-2 py-1 rounded uppercase tracking-widest">
                    Code: {error.code}
                  </span>
                )}
              </div>
              
              {error.detail && (
                <p className="text-sm text-red-700/80 leading-relaxed font-medium pl-11">
                  {error.detail}
                </p>
              )}

              <div className="flex items-center gap-4 pl-11">
                <button 
                  onClick={handleSearch}
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-all shadow-sm active:scale-95"
                >
                  <RefreshCw className="w-4 h-4" /> Try Again
                </button>
                <p className="text-xs text-red-400 italic">
                  Note: Some sites block automated scraping.
                </p>
              </div>
            </motion.div>
          )}
        </section>

        {/* Unique Functionality List */}
        <section className="mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { title: "Multi-Packet Engine", desc: "Parallel 4-chunk downloading for maximum speed.", icon: <Download className="w-4 h-4" /> },
              { title: "Stealth Scraping", desc: "Rotates User-Agents & mimics human behavior.", icon: <Eye className="w-4 h-4" /> },
              { title: "Live Speed Tracking", desc: "Real-time throughput monitoring for all tasks.", icon: <Clock className="w-4 h-4" /> },
              { title: "Metadata Extraction", desc: "Deep scan for author, title, and creation dates.", icon: <Fingerprint className="w-4 h-4" /> },
              { title: "Advanced Preview", desc: "Full viewer with zoom & page controls.", icon: <FileText className="w-4 h-4" /> },
              { title: "Smart Queue", desc: "Concurrent control with pause & retry logic.", icon: <ListOrdered className="w-4 h-4" /> },
            ].map((feature, i) => (
              <div key={i} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                    {feature.icon}
                  </div>
                  <h5 className="text-sm font-bold text-gray-900">{feature.title}</h5>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Queue Section */}
        <AnimatePresence>
          {queue.length > 0 && (
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-12 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
            >
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ListOrdered className="w-5 h-5 text-blue-600" />
                  <h2 className="font-bold text-gray-900">Download Queue</h2>
                  <span className="text-xs font-bold bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                    {queue.filter(t => t.status === 'completed').length} / {queue.length}
                  </span>
                </div>
                <button 
                  onClick={() => setQueue([])}
                  className="text-xs font-bold text-gray-400 hover:text-red-500 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear Queue
                </button>
              </div>
              <div className="divide-y divide-gray-50 max-h-80 overflow-y-auto">
                {queue.map((task) => (
                  <div key={task.id} className="px-6 py-3 flex items-center gap-4 group">
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                      task.status === 'completed' ? "bg-green-100 text-green-600" :
                      task.status === 'downloading' ? "bg-blue-100 text-blue-600" :
                      task.status === 'failed' ? "bg-red-100 text-red-600" : "bg-gray-100 text-gray-400"
                    )}>
                      {task.status === 'downloading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-sm font-bold truncate">{task.name}</span>
                          {task.status === 'downloading' && task.speed && (
                            <span className="text-[10px] font-mono text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">
                              {task.speed}
                            </span>
                          )}
                        </div>
                        <span className={cn(
                          "text-[10px] font-bold uppercase tracking-wider",
                          task.status === 'completed' ? "text-green-600" :
                          task.status === 'downloading' ? "text-blue-600" :
                          task.status === 'failed' ? "text-red-600" : "text-gray-400"
                        )}>
                          {task.status}
                        </span>
                      </div>
                      <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
                        <motion.div 
                          className={cn(
                            "h-full transition-all",
                            task.status === 'completed' ? "bg-green-500" :
                            task.status === 'failed' ? "bg-red-500" : "bg-blue-500"
                          )}
                          initial={{ width: 0 }}
                          animate={{ width: `${task.progress}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {task.status === 'failed' && (
                        <button 
                          onClick={() => toggleTaskStatus(task.id)}
                          className="p-1.5 hover:bg-blue-50 rounded-md text-blue-600 transition-colors"
                          title="Retry"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      )}
                      {task.status !== 'completed' && task.status !== 'failed' && (
                        <button 
                          onClick={() => toggleTaskStatus(task.id)}
                          className="p-1.5 hover:bg-gray-100 rounded-md text-gray-500 transition-colors"
                          title={task.status === 'downloading' ? "Pause" : "Resume"}
                        >
                          {task.status === 'downloading' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </button>
                      )}
                      <button 
                        onClick={() => removeFromQueue(task.id)}
                        className="p-1.5 hover:bg-red-50 rounded-md text-gray-400 hover:text-red-500 transition-colors"
                        title="Remove"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>
          )}
        </AnimatePresence>
        <AnimatePresence mode="wait">
          {pdfs.length > 0 ? (
            <motion.div
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              {pdfs.map((pdf, index) => (
                <motion.div
                  key={pdf.url}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => toggleSelect(pdf.url)}
                  className={cn(
                    "group relative p-4 rounded-2xl border-2 cursor-pointer transition-all hover:shadow-md",
                    selectedUrls.has(pdf.url)
                      ? "bg-blue-50 border-blue-200"
                      : "bg-white border-[#E5E7EB] hover:border-blue-200"
                  )}
                >
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors",
                      selectedUrls.has(pdf.url) ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-400 group-hover:bg-blue-100 group-hover:text-blue-500"
                    )}>
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-sm truncate pr-8" title={pdf.name}>
                        {pdf.name}
                      </h3>
                      <p className="text-xs text-gray-400 truncate mt-1" title={pdf.url}>
                        {pdf.url}
                      </p>
                      <div className="flex items-center gap-3 mt-3">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            addToQueue(pdf);
                          }}
                          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" /> Add to Queue
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setPreviewPdf(pdf);
                            extractMetadata(pdf);
                          }}
                          className="text-xs font-bold text-gray-500 hover:text-gray-700 flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" /> Preview
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            extractMetadata(pdf);
                          }}
                          disabled={pdf.isExtractingMetadata}
                          className={cn(
                            "text-xs font-bold flex items-center gap-1 transition-colors",
                            pdf.metadata ? "text-green-600" : "text-gray-400 hover:text-gray-600"
                          )}
                        >
                          {pdf.isExtractingMetadata ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Info className="w-3 h-3" />
                          )}
                          {pdf.metadata ? "Metadata Ready" : "Get Metadata"}
                        </button>
                        <a
                          href={pdf.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-xs font-bold text-gray-400 hover:text-gray-600 flex items-center gap-1"
                        >
                          <ExternalLink className="w-3 h-3" /> Open
                        </a>
                      </div>
                    </div>
                    <div className="absolute top-4 right-4">
                      {selectedUrls.has(pdf.url) ? (
                        <CheckCircle2 className="w-5 h-5 text-blue-600" />
                      ) : (
                        <div className="w-5 h-5 rounded-full border-2 border-gray-200" />
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : !isLoading && !error && (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-gray-200"
            >
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-300" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">No PDFs found yet</h3>
              <p className="text-gray-400 max-w-xs mx-auto mt-2">
                Enter a URL above to start searching for PDF documents on that page.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bulk Download Progress Overlay */}
      <AnimatePresence>
        {bulkStatus && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 z-50 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
          >
            <div className="p-4 bg-blue-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileArchive className="w-4 h-4" />
                <span className="text-sm font-bold">Creating ZIP...</span>
              </div>
              <span className="text-xs font-medium opacity-80">
                {bulkStatus.completed} / {bulkStatus.total}
              </span>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-500 truncate max-w-[180px]">
                  {bulkStatus.currentFile || "Starting..."}
                </span>
                <span className="text-xs font-extrabold text-blue-600">
                  {bulkStatus.percent}%
                </span>
              </div>
              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-blue-600"
                  initial={{ width: 0 }}
                  animate={{ width: `${bulkStatus.percent}%` }}
                  transition={{ type: "spring", bounce: 0, duration: 0.3 }}
                />
              </div>
              <div className="mt-4 flex gap-1">
                {Array.from({ length: bulkStatus.total }).map((_, i) => (
                  <div 
                    key={i}
                    className={cn(
                      "h-1 flex-1 rounded-full transition-colors",
                      i < bulkStatus.completed ? "bg-blue-600" : 
                      i === bulkStatus.completed ? "bg-blue-200 animate-pulse" : "bg-gray-100"
                    )}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Preview Modal */}
      <AnimatePresence>
        {previewPdf && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setPreviewPdf(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-6xl h-[92vh] rounded-3xl overflow-hidden flex flex-col shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-3">
                  <FileText className="text-blue-600 w-5 h-5" />
                  <h3 className="font-bold text-gray-900 truncate max-w-md">{previewPdf.name}</h3>
                </div>
                
                {/* PDF Controls */}
                <div className="flex items-center gap-1 bg-gray-50 p-1 rounded-xl border border-gray-100">
                  <div className="flex items-center gap-1 pr-2 border-r border-gray-200">
                    <button 
                      onClick={() => setPreviewPage(Math.max(1, previewPage - 1))}
                      className="p-1.5 hover:bg-white hover:shadow-sm rounded-lg text-gray-600 transition-all"
                      title="Previous Page"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-bold px-2 min-w-[3rem] text-center">
                      Page {previewPage}
                    </span>
                    <button 
                      onClick={() => setPreviewPage(previewPage + 1)}
                      className="p-1.5 hover:bg-white hover:shadow-sm rounded-lg text-gray-600 transition-all"
                      title="Next Page"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="flex items-center gap-1 px-2 border-r border-gray-200">
                    <button 
                      onClick={() => setPreviewZoom(Math.max(25, previewZoom - 25))}
                      className="p-1.5 hover:bg-white hover:shadow-sm rounded-lg text-gray-600 transition-all"
                      title="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-bold px-2 min-w-[3rem] text-center">
                      {previewZoom}%
                    </span>
                    <button 
                      onClick={() => setPreviewZoom(Math.min(400, previewZoom + 25))}
                      className="p-1.5 hover:bg-white hover:shadow-sm rounded-lg text-gray-600 transition-all"
                      title="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                  </div>

                  <button 
                    onClick={() => {
                      setPreviewFit(!previewFit);
                      if (!previewFit) setPreviewZoom(100);
                    }}
                    className={cn(
                      "p-1.5 rounded-lg transition-all flex items-center gap-1.5 px-3",
                      previewFit ? "bg-blue-600 text-white shadow-md" : "hover:bg-white hover:shadow-sm text-gray-600"
                    )}
                    title="Fit to Page"
                  >
                    <Maximize className="w-4 h-4" />
                    <span className="text-[10px] font-bold uppercase">Fit</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => downloadSingle(previewPdf)}
                    className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 transition-colors"
                    title="Download"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      setPreviewPdf(null);
                      setPreviewPage(1);
                      setPreviewZoom(100);
                      setPreviewFit(false);
                    }}
                    className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="flex-1 bg-gray-100 relative flex overflow-hidden">
                {/* PDF Viewer */}
                <div className="flex-1 relative">
                  <iframe
                    src={`/api/proxy-pdf?url=${encodeURIComponent(previewPdf.url)}#page=${previewPage}&zoom=${previewFit ? 'page-fit' : previewZoom}`}
                    className="w-full h-full border-none"
                    title="PDF Preview"
                    key={`${previewPdf.url}-${previewPage}-${previewZoom}-${previewFit}`}
                  />
                </div>

                {/* Metadata Sidebar */}
                <AnimatePresence>
                  <motion.div 
                    initial={{ x: 300 }}
                    animate={{ x: 0 }}
                    className="w-80 bg-white border-l border-gray-100 p-6 overflow-y-auto shadow-xl z-10"
                  >
                    <div className="flex items-center gap-2 mb-6">
                      <Fingerprint className="w-5 h-5 text-blue-600" />
                      <h4 className="font-bold text-gray-900 uppercase tracking-wider text-sm">Document Metadata</h4>
                    </div>

                    {previewPdf.isExtractingMetadata ? (
                      <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                        <Loader2 className="w-8 h-8 animate-spin mb-4" />
                        <p className="text-xs font-medium">Extracting details...</p>
                      </div>
                    ) : previewPdf.metadata ? (
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                            <Tag className="w-3 h-3" /> Title
                          </label>
                          <p className="text-sm font-bold text-gray-800 leading-tight">
                            {previewPdf.metadata.title || "No Title Found"}
                          </p>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                            <User className="w-3 h-3" /> Author
                          </label>
                          <p className="text-sm font-medium text-gray-700">
                            {previewPdf.metadata.author || "Unknown Author"}
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                              <Calendar className="w-3 h-3" /> Created
                            </label>
                            <p className="text-xs font-medium text-gray-600">
                              {formatDate(previewPdf.metadata.creationDate)}
                            </p>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                              <FileText className="w-3 h-3" /> Pages
                            </label>
                            <p className="text-xs font-medium text-gray-600">
                              {previewPdf.metadata.pages || "N/A"}
                            </p>
                          </div>
                        </div>

                        <div className="pt-6 border-t border-gray-50 space-y-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Producer</label>
                            <p className="text-[11px] text-gray-500 font-medium">{previewPdf.metadata.producer || "N/A"}</p>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Creator</label>
                            <p className="text-[11px] text-gray-500 font-medium">{previewPdf.metadata.creator || "N/A"}</p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-20">
                        <button 
                          onClick={() => extractMetadata(previewPdf)}
                          className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors"
                        >
                          Load Metadata
                        </button>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="max-w-5xl mx-auto px-6 py-12 border-t border-gray-100 text-center">
        <p className="text-sm text-gray-400">
          Built for bulk PDF collection. Please respect the copyright of the files you download.
        </p>
      </footer>
    </div>
  );
}
