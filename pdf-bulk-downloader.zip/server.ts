import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import * as cheerio from "cheerio";
import { fileURLToPath } from "url";
import https from "https";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
  "Mozilla/5.0 (AppleWebKit/537.36; Chrome/122.0.0.0; Mobile; rv:123.0) SamsungBrowser/24.0",
];

const getRandomUserAgent = () => USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint to scrape PDF links
  app.post("/api/scrape", async (req, res) => {
    let { url, delay = 0 } = req.body;

    if (!url) {
      return res.status(400).json({ error: "URL is required" });
    }

    if (!/^https?:\/\//i.test(url)) {
      url = "https://" + url;
    }

    // Apply initial delay if requested
    if (delay > 0) {
      await sleep(Math.min(delay, 5000)); // Cap at 5s for safety
    }

    const maxRetries = 2;
    let lastError: any = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await axios.get(url, {
          headers: {
            "User-Agent": getRandomUserAgent(),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Referer": new URL(url).origin,
          },
          timeout: 60000,
          maxRedirects: 10,
          maxContentLength: 20 * 1024 * 1024,
          httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        });

        const $ = cheerio.load(response.data);
        const pdfLinks: { url: string; name: string }[] = [];
        const baseHref = $("base").attr("href");
        const effectiveBaseUrl = baseHref ? new URL(baseHref, url).href : url;

        $("a").each((_, element) => {
          const href = $(element).attr("href");
          if (!href) return;

          const isPdf = href.toLowerCase().split("?")[0].endsWith(".pdf") || 
                        $(element).attr("type") === "application/pdf" ||
                        (href.toLowerCase().includes("download") && href.toLowerCase().includes("pdf"));

          if (isPdf) {
            try {
              const absoluteUrl = new URL(href, effectiveBaseUrl).href;
              const name = $(element).text().trim() || 
                           $(element).attr("title")?.trim() || 
                           path.basename(absoluteUrl.split("?")[0]) || 
                           "document.pdf";
              
              if (!pdfLinks.some(link => link.url === absoluteUrl)) {
                pdfLinks.push({ url: absoluteUrl, name });
              }
            } catch (e) {}
          }
        });

        return res.json({ pdfs: pdfLinks, attempts: attempt + 1 });
      } catch (error: any) {
        lastError = error;
        console.error(`Attempt ${attempt + 1} failed:`, error.message);
        
        // Only retry on transient errors
        const isTransient = error.code === "ECONNABORTED" || 
                           error.code === "ETIMEDOUT" || 
                           (error.response?.status && error.response.status >= 500);
        
        if (!isTransient || attempt === maxRetries) break;
        
        // Wait before retry (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }

    // If we reach here, all attempts failed
    let message = "Failed to scrape website";
    let detail = lastError.message;
    let code = lastError.code || lastError.response?.status || "UNKNOWN";

    if (lastError.code === "ECONNABORTED" || lastError.code === "ETIMEDOUT") {
      message = "Connection Timed Out";
      detail = "The website took too long to respond (over 60s). This usually happens when the server is under heavy load or is intentionally slowing down scrapers.";
    } else if (lastError.response?.status === 403) {
      message = "Access Forbidden (403)";
      detail = "The website is actively blocking our request. They may have anti-bot protections like Cloudflare or Akamai.";
    } else if (lastError.response?.status === 429) {
      message = "Too Many Requests (429)";
      detail = "We are being rate-limited. Please wait a few minutes before trying again.";
    } else if (lastError.code === "ENOTFOUND") {
      message = "Domain Not Found";
      detail = "The URL provided does not seem to exist. Please check for typos.";
    } else if (lastError.code === "ECONNREFUSED") {
      message = "Connection Refused";
      detail = "The website server refused the connection. It might be down or blocking our IP.";
    }

    res.status(500).json({ 
      error: message, 
      detail: detail,
      rawError: lastError.message,
      code: code
    });
  });

  // Get PDF info (size, range support)
  app.get("/api/pdf-info", async (req, res) => {
    const pdfUrl = req.query.url as string;
    if (!pdfUrl) return res.status(400).json({ error: "URL is required" });

    try {
      const response = await axios.head(pdfUrl, {
        headers: {
          "User-Agent": getRandomUserAgent(),
          "Referer": new URL(pdfUrl).origin,
        },
        timeout: 15000,
        httpsAgent: new https.Agent({ rejectUnauthorized: false }),
      });

      const size = parseInt(response.headers["content-length"] || "0");
      const acceptRanges = response.headers["accept-ranges"] === "bytes";

      res.json({
        size,
        acceptRanges,
        contentType: response.headers["content-type"],
      });
    } catch (error: any) {
      // Fallback to GET if HEAD is not allowed
      try {
        const response = await axios.get(pdfUrl, {
          headers: {
            "User-Agent": getRandomUserAgent(),
            "Referer": new URL(pdfUrl).origin,
            "Range": "bytes=0-0"
          },
          timeout: 15000,
          httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        });
        
        const contentRange = response.headers["content-range"];
        const size = contentRange ? parseInt(contentRange.split("/")[1]) : 0;
        const acceptRanges = !!contentRange || response.headers["accept-ranges"] === "bytes";

        res.json({
          size,
          acceptRanges,
          contentType: response.headers["content-type"],
        });
      } catch (innerError: any) {
        res.status(500).json({ error: "Failed to fetch PDF info: " + innerError.message });
      }
    }
  });

  // Proxy endpoint to fetch PDF content (to avoid CORS)
  app.get("/api/proxy-pdf", async (req, res) => {
    const pdfUrl = req.query.url as string;
    const delay = parseInt(req.query.delay as string || "0");
    const range = req.headers.range || req.query.range;
    
    if (!pdfUrl) return res.status(400).send("URL is required");

    // Mimic human delay if requested
    if (delay > 0) {
      const jitter = Math.random() * 500;
      await sleep(delay + jitter);
    }

    try {
      const headers: any = {
        "User-Agent": getRandomUserAgent(),
        "Referer": new URL(pdfUrl).origin,
      };

      if (range) {
        headers["Range"] = range;
      }

      const response = await axios.get(pdfUrl, {
        responseType: "arraybuffer",
        headers,
        timeout: 60000,
        httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        validateStatus: (status) => status < 500, // Allow 206 Partial Content
      });

      // Forward relevant headers
      if (response.headers["content-range"]) {
        res.setHeader("Content-Range", response.headers["content-range"]);
      }
      if (response.headers["content-length"]) {
        res.setHeader("Content-Length", response.headers["content-length"]);
      }
      res.setHeader("Content-Type", response.headers["content-type"] || "application/pdf");
      res.status(response.status).send(response.data);
    } catch (error: any) {
      console.error("Proxy error:", error.message);
      res.status(500).send("Failed to fetch PDF: " + error.message);
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
